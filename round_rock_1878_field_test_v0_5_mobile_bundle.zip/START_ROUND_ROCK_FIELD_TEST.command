#!/bin/bash
cd "$(dirname "$0")"
PORT=8000
FILE="round_rock_1878_field_test_v0_5_mobile.html"
IP=$(ipconfig getifaddr en0 2>/dev/null)
if [ -z "$IP" ]; then IP=$(ipconfig getifaddr en1 2>/dev/null); fi
HOST=$(scutil --get LocalHostName 2>/dev/null)
clear
echo "ROUND ROCK 1878 — FIELD TEST v0.5"
echo ""
echo "Keep this window open during the field test."
echo "Your iPhone and Mac must be on the same Wi-Fi."
echo ""
if [ -n "$IP" ]; then
  echo "On iPhone Safari, open:"
  echo "http://$IP:$PORT/$FILE"
  echo ""
fi
if [ -n "$HOST" ]; then
  echo "Or try:"
  echo "http://$HOST.local:$PORT/$FILE"
  echo ""
fi
echo "Press Control-C here when you're finished."
echo ""
python3 -m http.server $PORT
