ROUND ROCK 1878 — FIELD TEST v0.5 MOBILE

1. Unzip this folder on your Mac.
2. Double-click START_ROUND_ROCK_FIELD_TEST.command.
3. If macOS blocks it: right-click the file, choose Open, then Open again.
4. Keep that Terminal window open.
5. Put your iPhone on the same Wi-Fi as the Mac.
6. In iPhone Safari, type the address shown in the Terminal window.
7. You should see: Round Rock 1878 — The New Hand.

Notes remain in the phone browser's local storage for this served page. Export them at the end of the test.
