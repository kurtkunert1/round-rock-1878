CONTENTSTREAM — ROUND ROCK PLAYABLE FIELD 1.3

WHAT CHANGED
- Fixes the dead connection mismatch in 1.2: the old frontend did not send expression_catalog, while the backend required it.
- Fixes the second mismatch: the frontend expected response_text, but the backend schema only allowed old clip selection.
- Keeps the Six Questions as the resolver.
- Adds bounded area state: Old Town -> Brushy Creek -> New Round Rock.
- Adds fog/resolution rather than authored route progression.
- Seeds the opening with just enough momentum: Jeb, Rangers, Sam Bass, Old Town direction, and clear conversational handles.
- Adds current-area object inventories.
- Adds field_pulse events so objects can initiate when the walk has gone quiet.
- Historical facts guide the play; unnamed connective objects may create plausible interaction without being presented as documented fact.

FILES
1. index.html — Render Static Site frontend
2. server.js — Render Web Service backend
3. package.json — Node start command

DEPLOY
Replace these three files in the repo root and commit together.
Render should redeploy both services from the repo.

STATIC SITE
Open the current Render Static Site URL (previously round-rock-1878-2.onrender.com).

WEB SERVICE
https://round-rock-1878.onrender.com
Health check:
https://round-rock-1878.onrender.com/health
Expected service name after deployment:
contentstream-round-rock-playable-1.3

FIELD TEST
1. Tap Begin. Jeb should speak the opening impulse.
2. Do not force the Bass story. Respond naturally or simply walk and observe.
3. If nothing has happened for about 65-70 seconds, the client asks the resolver whether a current-area object has sufficient reason to act.
4. The manual Field pulse button triggers the same check immediately for testing.
5. Watch the State panel only when debugging. Fog should open based on resolution, not turn count.

IMPORTANT
This is intentionally not GPS-driven yet. Physical movement statements are visitor claims, not independently verified location facts.
