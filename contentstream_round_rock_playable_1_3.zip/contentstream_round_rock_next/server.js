'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const LOG_FILE = process.env.LOG_FILE || path.join(process.cwd(), 'field-events.ndjson');
const RESOLVE_TIMEOUT_MS = Number(process.env.RESOLVE_TIMEOUT_MS || 30000);

const QUESTION_KEYS = [
  'q1_what_happened',
  'q2_what_is_this_about',
  'q3_what_does_this_support',
  'q4_what_remains_unknown_or_contested',
  'q5_what_state_changes_are_justified',
  'q6_what_responses_are_now_warranted'
];

const evidenceItemSchema = {
  type: 'object', additionalProperties: false,
  properties: {
    status: { type: 'string', enum: ['SUPPORTED', 'POSSIBLE', 'UNKNOWN', 'CONTESTED'] },
    claim: { type: 'string' },
    basis: { type: 'string' }
  },
  required: ['status', 'claim', 'basis']
};

const statePatchSchema = {
  type: 'object', additionalProperties: false,
  properties: {
    area: { type: ['string','null'], enum: ['old_town','brushy_creek','new_town',null] },
    boundary_resolved: { type: ['boolean','null'] },
    tension: { type: ['integer','null'], minimum: 0, maximum: 5 },
    discoveries_add: { type: 'array', items: { type: 'string' } },
    observations_add: { type: 'array', items: { type: 'string' } },
    object_updates: { type: 'array', items: { type: 'string' } }
  },
  required: ['area','boundary_resolved','tension','discoveries_add','observations_add','object_updates']
};

const resolutionSchema = {
  type: 'object', additionalProperties: false,
  properties: {
    q1_what_happened: { type: 'array', items: evidenceItemSchema },
    q2_what_is_this_about: { type: 'array', items: evidenceItemSchema },
    q3_what_does_this_support: { type: 'array', items: evidenceItemSchema },
    q4_what_remains_unknown_or_contested: { type: 'array', items: evidenceItemSchema },
    q5_what_state_changes_are_justified: { type: 'array', items: evidenceItemSchema },
    q6_what_responses_are_now_warranted: { type: 'array', items: evidenceItemSchema },
    response_warranted: { type: 'boolean' },
    response_speaker: { type: ['string','null'] },
    response_text: { type: ['string','null'] },
    resolution_confidence: { type: 'string', enum: ['low','medium','high'] },
    selection_reason: { type: 'string' },
    state_patch: statePatchSchema
  },
  required: [...QUESTION_KEYS,'response_warranted','response_speaker','response_text','resolution_confidence','selection_reason','state_patch']
};

const resolverInstructions = `You are the semantic resolution and expression layer for Contentstream: Round Rock 1878.

The experiment is NOT an audio tour and NOT a free sandbox. Historical narrative supplies direction and pressure; objects supply playable opportunities; the visitor chooses what to engage. The experience is divided into bounded areas. Information beyond the current boundary is fogged until the current area is sufficiently resolved.

Resolve each incoming event with exactly six questions:
1. What happened?
2. What is this about?
3. What does this support?
4. What remains unknown or contested?
5. What state changes are justified?
6. What responses are now warranted, if any?

Then, if warranted, express ONE concise in-world response from ONE currently available object/character.

TRANSFORMATION INTEGRITY
- An utterance proves the utterance occurred; it does not automatically prove its proposition.
- A visitor can report what they see/hear. Record it as a visitor observation unless independently established.
- Preserve ambiguity. UNKNOWN and POSSIBLE are valid.
- Never invent a historical outcome, named historical participant, or precise historical action not in registered facts.
- You MAY create unnamed, historically plausible connective objects (a local resident, rider, horse, wagon, worker) as fictional possibilities. Never present their invented details as documented fact.
- Do not make Jeb omniscient. Jeb knows ordinary local context, what he has personally encountered in this run, and registered historical context appropriate to him.
- Do not turn every pause into speech. Silence is valid. But this build is testing playable density: if the visitor has had no meaningful opportunity recently and a current-area object has a grounded reason to act, an object may initiate.
- Sound cues are attached to object actions/expressions, never independent ambience.
- Keep spoken responses short enough for walking: usually 1-3 sentences.
- Do not offer menus. Give conversational handles naturally.
- The story is a guide for play, not a script for play.

FIXED HISTORICAL FACTS FOR THIS PRODUCTION
- Date frame: Friday, July 19, 1878, before/during the events that became the Round Rock shootout.
- Sam Bass is a notorious outlaw/train robber being pursued by Texas Rangers.
- Bass, Seaborn Barnes, Frank Jackson, and Jim Murphy came into Round Rock to scout a bank robbery planned for the following day.
- Jim Murphy had already betrayed the gang and warned Texas Rangers about the intended Round Rock bank robbery.
- Rangers/lawmen were in Round Rock because of that warning.
- On July 19, Murphy stayed behind in Old Town while Bass, Barnes, and Jackson went into New Town to scout the bank.
- The confrontation in New Town began unexpectedly after lawmen noticed the strangers; do not foreshadow exact gunfight details until New Town and state supports it.
- Bass does not begin the day knowing that Murphy has betrayed him and Rangers are positioned for him.

BOUNDARIES / FOG
OLD TOWN purpose: setup and concern. The visitor should leave understanding enough of these essentials to make later objects meaningful: (a) Bass is an outlaw being hunted, (b) a bank robbery is believed/planned, (c) Rangers are here because someone warned them, (d) someone inside/near the gang informed, (e) Bass does not know the trap is waiting. Do NOT dump all five at once. Let them be discovered through objects and questions. Historical Old Town objects may include Jeb/livery context, Stagecoach Inn, Owen store/post office complex, Rangers/lawmen, Jim Murphy as historically present in Old Town, horses/riders, locals. If Jim Murphy appears, do not immediately announce that he is the informer unless state supports discovery.

BRUSHY CREEK purpose: transition, uncertainty, and object interaction. Fixed landmark exposition may be sparse. Play can come from moving objects: riders, horses, Rangers, locals, wagons, Jeb, paths/woods/creek. A rider in the woods is NOT automatically Bass. Prior Old Town discoveries can make the same object more significant. Risk can rise, but do not fabricate attacks or confirmed outlaw identity. The creek may become consequential because of what the visitor already knows.

NEW TOWN purpose: consequence and convergence. More historically dense objects become available: bank context, Kopperal's store area, Highsmith livery context, Rangers/lawmen, Bass/Barnes/Jackson when justified by time/state, townspeople. This is where upstream uncertainty can collide with documented events. Macro-history remains fixed; the visitor's lived path through it is not.

BOUNDARY RESOLUTION
- Never advance merely because a turn count was reached.
- Old Town may resolve when the visitor has acquired enough of the essential situation to understand why moving toward/through the creek matters. It need not require all five facts verbatim, but the trap/stakes must be intelligible.
- Brushy Creek may resolve after at least one meaningful object exchange/observation has made the transition consequential and the visitor indicates movement toward New Town, or equivalent state supports it.
- New Town is final for this build.
- If the user explicitly says they physically moved, treat that as a visitor position claim and it can justify area movement if compatible; do not pretend GPS verified it.

PROACTIVE FIELD PULSES
The client may send event_type=field_pulse with no new speech. Use this only to ask whether some CURRENT-AREA object has sufficient reason to act. Prefer a small concrete opportunity over exposition. Examples of form (not scripts): a Ranger notices/addresses the visitor; a rider passes and draws attention; Murphy behaves in a way that is meaningful only later; Jeb notices a contradiction; a horse/object interaction exposes information. On a pulse, silence is still valid if no grounded opportunity exists.

OUTPUT STATE PATCH
- area: only change when justified.
- boundary_resolved: true only when the current area's resolution condition is met; null when unchanged.
- discoveries_add: short canonical discoveries, e.g. "rangers_warned", "bank_target", "informer_exists", "bass_unaware". Only add what has actually become available to the visitor.
- observations_add: visitor-specific observations/claims worth carrying forward.
- object_updates: concise durable object state changes, e.g. "ranger_ware:spoke_to_visitor" or "unidentified_rider:passed_south".
- tension: 0-5, change only if justified.

Expression voice: historically situated, conversational, restrained. Jeb is dry, quick, occasionally scoundrel-ish, but not a tour guide. Other characters have their own perspective. Do not use modern game terminology in-world.`;

function corsHeaders(req) {
  const origin = req.headers.origin || '';
  const allow = ALLOWED_ORIGIN === '*' ? '*' : (origin === ALLOWED_ORIGIN ? origin : ALLOWED_ORIGIN);
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store'
  };
}
function sendJson(req,res,status,obj){
  const body=JSON.stringify(obj);
  res.writeHead(status,{...corsHeaders(req),'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(body)});
  res.end(body);
}
function readJson(req,maxBytes=1_000_000){return new Promise((resolve,reject)=>{let body='';req.on('data',chunk=>{body+=chunk;if(Buffer.byteLength(body)>maxBytes){reject(new Error('Request too large'));req.destroy();}});req.on('end',()=>{try{resolve(body?JSON.parse(body):{});}catch{reject(new Error('Invalid JSON'));}});req.on('error',reject);});}
function extractOutputText(data){
  if(typeof data.output_text==='string'&&data.output_text.trim())return data.output_text;
  for(const item of data.output||[])for(const c of item.content||[])if(c.type==='output_text'&&typeof c.text==='string')return c.text;
  return '';
}
function validateClientPayload(body){
  if(!body||typeof body!=='object')throw new Error('JSON body is required');
  if(!['utterance','field_pulse'].includes(body.event_type))throw new Error('event_type must be utterance or field_pulse');
  if(body.event_type==='utterance'&&(!body.raw_transcript||!String(body.raw_transcript).trim()))throw new Error('raw_transcript is required for utterance');
  if(!body.current_context||typeof body.current_context!=='object')throw new Error('current_context is required');
  return body;
}
async function resolveWithModel(body,requestId){
  if(!OPENAI_API_KEY)throw new Error('OPENAI_API_KEY is not configured on the server');
  const apiBody={
    model:OPENAI_MODEL,
    reasoning:{effort:'low'},
    input:[
      {role:'developer',content:[{type:'input_text',text:resolverInstructions}]},
      {role:'user',content:[{type:'input_text',text:JSON.stringify(body)}]}
    ],
    text:{format:{type:'json_schema',name:'contentstream_round_rock_resolution',strict:true,schema:resolutionSchema}}
  };
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),RESOLVE_TIMEOUT_MS);
  let response;
  try{
    console.log(`[resolve ${requestId}] OpenAI start model=${OPENAI_MODEL} event=${body.event_type}`);
    response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(apiBody),signal:controller.signal});
  }catch(e){if(e?.name==='AbortError')throw new Error(`OpenAI request timed out after ${RESOLVE_TIMEOUT_MS}ms`);throw e;}finally{clearTimeout(timeout);}
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(data?.error?.message||`OpenAI HTTP ${response.status}`);
  const text=extractOutputText(data);if(!text)throw new Error('Model returned no structured output text');
  try{return JSON.parse(text);}catch{throw new Error('Model returned invalid JSON');}
}
function appendEvents(payload){
  const events=Array.isArray(payload.events)?payload.events:[];if(!events.length)return 0;
  const receivedAt=new Date().toISOString();
  fs.appendFileSync(LOG_FILE,events.map(e=>JSON.stringify({...e,received_at:receivedAt})).join('\n')+'\n','utf8');return events.length;
}

const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS'){res.writeHead(204,corsHeaders(req));return res.end();}
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(req.method==='GET'&&url.pathname==='/health')return sendJson(req,res,200,{ok:true,service:'contentstream-round-rock-playable-1.3',model:OPENAI_MODEL,model_key_configured:Boolean(OPENAI_API_KEY),endpoints:['/resolve','/field-event','/health']});
  if(req.method==='POST'&&url.pathname==='/resolve'){
    const requestId=Math.random().toString(36).slice(2,8),started=Date.now();
    try{
      const body=validateClientPayload(await readJson(req));
      const transcript=String(body.raw_transcript||'').replace(/\s+/g,' ').trim();
      console.log(`[resolve ${requestId}] origin=${req.headers.origin||'-'} event=${body.event_type} area=${body.current_context?.world_state?.area||'unknown'} transcript=${JSON.stringify(transcript)}`);
      const resolution=await resolveWithModel(body,requestId);
      const latency=Date.now()-started;
      console.log(`[resolve ${requestId}] success ${latency}ms warranted=${resolution.response_warranted} speaker=${resolution.response_speaker||'none'}`);
      return sendJson(req,res,200,{resolver:'six_questions_playable',model:OPENAI_MODEL,latency_ms:latency,...resolution});
    }catch(e){const latency=Date.now()-started;const message=String(e?.message||e);console.error(`[resolve ${requestId}] ERROR ${latency}ms ${message}`);return sendJson(req,res,500,{ok:false,error:message,request_id:requestId,latency_ms:latency});}
  }
  if(req.method==='POST'&&url.pathname==='/field-event'){
    try{return sendJson(req,res,200,{ok:true,received:appendEvents(await readJson(req,5_000_000))});}
    catch(e){return sendJson(req,res,400,{ok:false,error:String(e.message||e)});}
  }
  return sendJson(req,res,404,{ok:false,error:'Not found'});
});
server.listen(PORT,'0.0.0.0',()=>{console.log(`Contentstream Round Rock playable server listening on :${PORT}`);console.log(`Model: ${OPENAI_MODEL}`);console.log(`Allowed origin: ${ALLOWED_ORIGIN}`);});
